Place any audio file (.ogg, .wav, or .mp3) in the Assets folder for it to play while being jammed. 

Place a webm with the name clip.webm in the Assets folder for it to be drawn over the screen while being jammed.

The webm's audio tends to be very quiet while in game so I recommend just muting it and overlaying whatever you want as an audio file.

Software is provoided as-is under the MIT license.